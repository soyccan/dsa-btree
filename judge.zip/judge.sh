#!/bin/bash

OUTPATH="/dev/stderr"
CHECKER="./checker"

help() {
    echo "Usage: ./judge.sh [executable solution code] [option]"
    echo "Option list:"
    echo -e "-n [number]\t Let the judge do random tests [number] times."
    echo -e "-s [number]\t Decide the tree size in the random test, the default number is 10."
    exit
}

if [[ $# -lt 1 ]]; then
    help
fi

if [[ ! -x "$1" ]]; then
    help
fi
code=$1
shift 1

runtime=0
treesz=10
while [[ -n $1 ]]; do
    if [[ $1 =~ ^-n$ ]]; then
        if [[ $# -lt 2 || ! $2 =~ ^[1-9][0-9]*$ ]]; then
            echo "Missing/Wrong parameter of -n, try ./judge.sh -h for more information."
            exit
        fi
        runtime=$2
        shift 2
    elif [[ $1 =~ ^-s$ ]]; then
        if [[ $# -lt 2 || ! $2 =~ ^[1-9][0-9]*$ ]]; then
            echo "Missing/Wrong parameter of -s, try ./judge.sh -h for more information."
            exit
        fi
        treesz=$2
        shift 2
    elif [[ $1 =~ ^-h$ ]];then
        help
    else
        echo "Unknown option $1, try ./judge.sh -h for more information."
        exit
    fi
done

if [[ ! $code =~ ^~ ]] && [[ ! $code =~ ^/ ]]; then
    code="./$code"
fi

for i in $(find TestCases/*); do
    echo "Judge is using $i:" > "$OUTPATH"
    $code < $i | "$CHECKER" > "$OUTPATH"
    if [[ "$?" -ne "0" ]]; then
        echo "
Failed on $i"
        exit
    fi
done

temp=$(mktemp)
for (( i = 0; i < $runtime; i++)) 
do
    echo "Judge is using random:" > "$OUTPATH"
    echo "$treesz" | ./generator $(( $RANDOM * 32768 + $RANDOM)) > $temp
    $code < $temp | "$CHECKER" > "$OUTPATH"
    if [[ "$?" -ne "0" ]]; then
        echo "
Failed on random test:"
        cat $temp
        exit
    fi
done

echo "
Final result: Passed"
