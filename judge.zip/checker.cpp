#include<iostream>
using namespace std;

const int MAXN = 100000;
int lch[MAXN + 5], rch[MAXN + 5], color[MAXN + 5];
int black_depth = -1;

int dfs(int u) {
    if (u == 0)
        return 1;
    int a = dfs(lch[u]);
    if (a != dfs(rch[u]))
        black_depth = -2;
    a += !color[u];
    if (black_depth != -2)
        black_depth = max(black_depth, a);
    return a;
}

int main() {
    int n, root, internal = 1, exit_code = 0;
    cin >> n >> root;
    for (int i = 1; i <= n; ++i)
        cin >> lch[i] >> rch[i] >> color[i];
    cout << "Root Property: ";
    if (color[root] != 0)
        cout << "Failed\n", exit_code = 1;
    else
        cout << "Passed\n";
    cout << "External Property: Passed\n";
    for (int i = 1; i <= n; ++i)
        if (color[i] == 1 && (color[lch[i]] == 1 || color[rch[i]] == 1))
            internal = 0;
    cout << "Internal Property: ";
    if (internal == 1)
        cout << "Passed\n";
    else
        cout << "Failed\n", exit_code = 1;
    dfs(root);
    cout << "Depth Property: ";
    if (black_depth == -2)
        cout << "Failed\n", exit_code = 1;
    else
        cout << "Passed with balck depth " << black_depth << "\n";
    return exit_code;
}
